

#ifndef DELAY_H_
#define DELAY_H_

#include "stdint.h"

#define DELAY 65000

void delay(uint16_t delay);

#endif /* DELAY_H_ */
